# Formbuilder embedding demo

Steps to the integration build:

Build assets:

```
npm run build
```

Adjust dist/index.html path to asset files.

See embedding-example.html for an example how to use it in the embedding application (paths to asset directory should be relative)