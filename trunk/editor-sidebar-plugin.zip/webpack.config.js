module.exports = require('../../../../webpack.config.js');
