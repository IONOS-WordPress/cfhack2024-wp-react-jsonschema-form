<?php
/**
 * Plugin Name:       formbuilder-embedded
 * Description:       Exposing a react-renderer playground page
 * Requires at least: 6.4
 * Requires PHP:      7.0
 * Version:           1.0.0
 * Author:            The Hackathon Project Contributors
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       rjsf-renderer-playground
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
